# AI as an API
Learn to create & deploy a deep learning algorithm into a production REST API using Python, Keras, FastAPI, & NoSQL.